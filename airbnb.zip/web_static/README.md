![ALX-Holberton Best School logo](https://storage.googleapis.com/www-paredro-com/uploads/2019/03/El-logo-de-Airbnb-es-el-si%CC%81mbolo-de-la-gente-lugares-amor-y-un-22A22.jpg)
# 0x01. AirBnB clone - Web static
This directory is about web with style in css
### about links for view web-sites:

https://dovineowuor.github.io/AirBnB_clone/web_static/0-index.html
https://dovineowuor.github.io/AirBnB_clone/web_static/1-index.html
htps://dovineowuor.github.io/AirBnB_clone/web_static/2-index.html
https://dovineowuor.github.io/AirBnB_clone/web_static/3-index.html
https://dovineowuor.github.io/AirBnB_clone/web_static/4-index.html

